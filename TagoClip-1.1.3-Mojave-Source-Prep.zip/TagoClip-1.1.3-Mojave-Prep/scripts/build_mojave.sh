#!/usr/bin/env bash
# Build TagoClip 1.1.3 for Intel x86_64 with macOS 10.14 as the deployment target.
# This script must run on macOS with Xcode command-line tools installed.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() { echo "ERROR: $*" >&2; exit 1; }

[[ "$(uname -s)" == "Darwin" ]] || fail "Run this script on macOS. A Linux/Windows host cannot produce the required macOS AU/VST3 bundles."
for tool in git cmake npm xcode-select lipo otool; do
    command -v "$tool" >/dev/null 2>&1 || fail "Required tool not found: $tool"
done
xcode-select -p >/dev/null 2>&1 || fail "Xcode or the Xcode Command Line Tools are not configured."

# GitHub source ZIP files omit Git submodule contents; restore the version recorded by the project notes.
if [[ ! -f third_party/JUCE/CMakeLists.txt ]]; then
    if [[ -d third_party/JUCE ]] && [[ -n "$(find third_party/JUCE -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
        fail "third_party/JUCE exists but is not a JUCE checkout. Move it aside and rerun."
    fi
    rm -rf third_party/JUCE
    mkdir -p third_party
    echo "==> Fetching JUCE 8.0.14"
    git clone --depth 1 --branch 8.0.14 https://github.com/juce-framework/JUCE.git third_party/JUCE
fi

[[ -f ui/package-lock.json ]] || fail "ui/package-lock.json is missing."

echo "==> Installing locked UI dependencies"
(cd ui && npm ci)

echo "==> Building the bundled WebView UI"
bash scripts/build-ui.sh

echo "==> Configuring Intel-only Release build (deployment target macOS 10.14)"
cmake -S . -B build-mojave \
    -DCMAKE_BUILD_TYPE=Release \
    -DTAGOCLIP_DEV_UI=OFF \
    -DCMAKE_OSX_ARCHITECTURES=x86_64 \
    -DCMAKE_OSX_DEPLOYMENT_TARGET=10.14

echo "==> Compiling VST3 and Audio Unit"
cmake --build build-mojave --config Release --target TagoClip_VST3 TagoClip_AU -j "$(sysctl -n hw.ncpu)"

ART="$ROOT/build-mojave/TagoClip_artefacts/Release"
VST3="$ART/VST3/TagoClip.vst3"
AU="$ART/AU/TagoClip.component"
[[ -d "$VST3" ]] || fail "VST3 output missing: $VST3"
[[ -d "$AU" ]] || fail "AU output missing: $AU"

# Preserve third-party attribution inside each resulting bundle.
for BUNDLE in "$VST3" "$AU"; do
    mkdir -p "$BUNDLE/Contents/Resources"
    cp THIRD_PARTY_LICENSES.txt "$BUNDLE/Contents/Resources/"
    BIN="$BUNDLE/Contents/MacOS/TagoClip"
    [[ -f "$BIN" ]] || fail "Plugin executable missing: $BIN"
    ARCHS="$(lipo -archs "$BIN")"
    [[ "$ARCHS" == "x86_64" ]] || fail "Expected x86_64-only binary, found architectures: $ARCHS"
    MINIMUMS="$(otool -l "$BIN" | awk '
        /cmd LC_BUILD_VERSION/ { mode = 1; next }
        /cmd LC_VERSION_MIN_MACOSX/ { mode = 2; next }
        /cmd / { mode = 0 }
        mode == 1 && $1 == "minos" { print $2; mode = 0 }
        mode == 2 && $1 == "version" { print $2; mode = 0 }
    ' | sort -u)"
    echo "==> $(basename "$BUNDLE"): arch=$ARCHS, declared minimum macOS=${MINIMUMS:-UNDETECTED}"
    echo "$MINIMUMS" | grep -Eq '^10\.14([.]|$)' || fail "Could not verify macOS 10.14 deployment target in $BIN"
done

echo
echo "Build outputs (unsigned, for local validation):"
echo "  VST3: $VST3"
echo "  AU:   $AU"
echo "This script does not sign, notarize, or create a .pkg installer."
