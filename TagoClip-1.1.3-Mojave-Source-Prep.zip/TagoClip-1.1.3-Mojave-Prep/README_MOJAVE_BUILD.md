# TagoClip 1.1.3: Intel macOS Mojave build preparation

This is a source-side build preparation, **not a compiled or verified plugin release**.

## What was established from the supplied installer

- The shipped VST3 and AU binaries are universal (`x86_64` + `arm64`).
- Both Mach-O slices declare macOS **11.0.0** as their minimum OS. This is why the supplied build is not a Mojave-compatible binary.
- The source project pins JUCE **8.0.14** in `CLAUDE.md`.
- The release script hardcodes `CMAKE_OSX_DEPLOYMENT_TARGET=11.0` and `CMAKE_OSX_ARCHITECTURES="arm64;x86_64"`.
- The GitHub ZIP omits the JUCE submodule and `ui/webui.zip`. The build script restores JUCE 8.0.14 and regenerates the bundled UI.

## Build target

`scripts/build_mojave.sh` configures the project for:

- Intel `x86_64` only
- `CMAKE_OSX_DEPLOYMENT_TARGET=10.14`
- Existing project language standard and JUCE 8.0.14
- VST3 and AU formats

The main release script is left unchanged, so its existing macOS 11+ release configuration is preserved.

## Requirements and use

1. Run this on a Mac with Xcode/Command Line Tools, CMake 3.24 or newer, Git, Node.js/npm, and internet access. JUCE's documented development requirements are newer than Mojave, so build on macOS 10.15.4 or later and target 10.14 at deployment time.
2. Unzip this project folder.
3. In Terminal, change into the extracted `TagoClip-1.1.3-Mojave-Prep` folder and run:

   ```sh
   bash scripts/build_mojave.sh
   ```

4. Inspect the architecture and minimum-OS checks printed at the end. Then test the output plugin in a compatible DAW on macOS 10.14.6.

The script produces unsigned local VST3/AU bundles. It does not create a signed/notarized installer. A successful compile and the script's binary checks are not a substitute for loading and audio/UI testing on an actual Mojave machine.
